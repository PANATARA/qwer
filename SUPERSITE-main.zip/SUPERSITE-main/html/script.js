// Когда пользователь прокручивает вниз 50px от верхней части документа, измените размер шрифта заголовка
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    document.getElementById("header").style.fontSize = "60px";

    
  } else {
    document.getElementById("header").style.fontSize = "250px";

  }
}
